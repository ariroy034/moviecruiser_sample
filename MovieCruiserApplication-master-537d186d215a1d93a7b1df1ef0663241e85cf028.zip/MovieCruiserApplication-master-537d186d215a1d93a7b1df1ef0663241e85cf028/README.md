Movie Cruiser Server Application
