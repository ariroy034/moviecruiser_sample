cd AuthenticateService
source ./env-variable.sh
cd ..
cd MovieCruiserService
source ./env-variable.sh
cd ..