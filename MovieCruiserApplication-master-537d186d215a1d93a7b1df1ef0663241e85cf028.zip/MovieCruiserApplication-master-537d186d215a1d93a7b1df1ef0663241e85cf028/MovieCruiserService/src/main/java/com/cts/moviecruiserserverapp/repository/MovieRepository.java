package com.cts.moviecruiserserverapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.moviecruiserserverapp.domain.Movie;

public interface MovieRepository extends JpaRepository<Movie, Integer> {

	List<Movie> findByUserId(String userId);
}
