import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Movie } from './movie';
import { map } from 'rxjs/operators/map';
import { Observable } from 'rxjs/Observable';
import { retry } from 'rxjs/operators';

@Injectable()
export class MovieService {
  
  tmdb_endpoint: string;
  imagePrefix: string;
  apiKey: string;
  watchlistEndpoint: string;
  searchEndipoint: string

  constructor(private http: HttpClient) {
    this.apiKey = "api_key=866f5eff51230afadd7ab6d07eb694ec";
    this.tmdb_endpoint = 'https://api.themoviedb.org/3';
    this.imagePrefix = "https://image.tmdb.org/t/p/w500";
    /* this.watchlistEndpoint = "http://localhost:3000/watchlist" */
    this.watchlistEndpoint = "http://localhost:8081/api/v1/movieservice/movie";
  }

  getMovies(type: string, page: number = 1): Observable<Array<Movie>> {
    const movieEndpoint = `${this.tmdb_endpoint}/movie/${type}?${this.apiKey}&page=${page}`
    return this.http.get(movieEndpoint).pipe(
      retry(3),
      map(this.pickMovieResults),
      map(this.transformPosterPath.bind(this))
    );
  }
  
  searchMovie(searchKey: string,page: number = 1): Observable<Array<Movie>> {
    if (searchKey.length > 0) {
      const searchEndpoint = `${this.tmdb_endpoint}/search/movie?${this.apiKey}&page=${page}&include_adult=false&query=${searchKey}`;
      return this.http.get(searchEndpoint).pipe(
        retry(3),
        map(this.pickMovieResults),
        map(this.transformPosterPath.bind(this))
      );
    }
  }

  addMovieToWatchlist(movie) {
    return this.http.post(this.watchlistEndpoint, movie);
  }

  getWatchlistedMovie(): Observable<Array<Movie>> {
    return this.http.get<Array<Movie>>(this.watchlistEndpoint);
  }

  deleteMovieFromWatchlist(movie) {
    const delUrl = `${this.watchlistEndpoint}/${movie.id}`;
    return this.http.delete(delUrl, {responseType: 'text'});
  }

  updateWatchlist(movie) {
    const delUrl = `${this.watchlistEndpoint}/${movie.id}`;
    return this.http.put(delUrl, movie);
  }

  pickMovieResults(response) {
    return response['results'];
  }

  transformPosterPath(movies): Array<Movie> {
    return movies.map(movie => {
      movie.poster_path = `${this.imagePrefix}${movie.poster_path}`;
      return movie;
    })
  }

}
